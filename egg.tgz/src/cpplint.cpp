// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cpplint\n", stdout);
  return lionss_run_workload("cpplint");
}
