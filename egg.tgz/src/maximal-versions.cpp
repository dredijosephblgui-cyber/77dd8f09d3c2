// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("maximal versions\n", stdout);
  return lionss_run_workload("maximal-versions");
}
