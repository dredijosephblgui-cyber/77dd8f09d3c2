// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("advisory sync"); }
int main(){
  announce();
  return lionss_run_workload("advisory-sync");
}
