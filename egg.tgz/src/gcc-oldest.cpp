// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gcc oldest"); }
int main(){
  announce();
  return lionss_run_workload("gcc-oldest");
}
