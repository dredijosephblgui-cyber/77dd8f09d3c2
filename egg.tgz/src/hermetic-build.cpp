// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("hermetic build"); }
int main(){
  announce();
  return lionss_run_workload("hermetic-build");
}
