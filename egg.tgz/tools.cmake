# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(bisect-regression src/bisect-regression.cpp)
set_property(TARGET bisect-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(bisect-regression lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(maximal-versions src/maximal-versions.cpp)
set_property(TARGET maximal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(maximal-versions lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(android-x86-64 src/android-x86-64.cpp)
set_property(TARGET android-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-x86-64 lionss pthread)

add_executable(doxygen src/doxygen.cpp)
set_property(TARGET doxygen PROPERTY CXX_STANDARD 11)
target_link_libraries(doxygen lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(unicode-tests src/unicode-tests.cpp)
set_property(TARGET unicode-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unicode-tests lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(cpplint src/cpplint.cpp)
set_property(TARGET cpplint PROPERTY CXX_STANDARD 11)
target_link_libraries(cpplint lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(mcdc-coverage src/mcdc-coverage.cpp)
set_property(TARGET mcdc-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(mcdc-coverage lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

